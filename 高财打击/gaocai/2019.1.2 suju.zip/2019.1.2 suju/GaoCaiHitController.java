package com.pango.rahc.specialcase.web;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pango.common.utils.DateUtils;
import com.pango.common.utils.StringUtils;
import com.pango.rahc.common.config.Global;
import com.pango.rahc.common.utils.Constants;
import com.pango.rahc.controller.common.BaseController;
import com.pango.rahc.pz.service.ScoutAttachmentService;
import com.pango.rahc.specialcase.pojo.GaoCaiHit;
import com.pango.rahc.specialcase.pojo.GaoCaiHit;
import com.pango.rahc.specialcase.pojo.GaoCaiHit;
import com.pango.rahc.specialcase.service.GaoCaiHitService;

/**
 * 通用申请表
 * @author zp
 * @version 2015-10-8
 */
@Controller
@RequestMapping(value = "/doorwindow/gaoCaiHit")
public class GaoCaiHitController extends BaseController {

	@Autowired
	private GaoCaiHitService gaoCaiHitService;	

	@Autowired
	private ScoutAttachmentService scoutAttachmentService;	
	
	
	@ModelAttribute("gaoCaiHit")
	public GaoCaiHit get(@RequestParam(required = false) String id) {
		if (StringUtils.isNotBlank(id)) {
			return gaoCaiHitService.findById(id);
		} else {
			return new GaoCaiHit();
		}
	}
	@RequestMapping(value = "list")
	public String list( Model model,GaoCaiHit gaoCaiHit,@RequestParam(value = "page", required = false, defaultValue = "1") int page) {    

		PageHelper.startPage(page, Integer.parseInt(Global.getConfig("page.pageSize")));
		PageHelper.orderBy("get_date desc");
		
		if (gaoCaiHit.getGetDateEnd() != null) {
			gaoCaiHit.setGetDateEnd(DateUtils.getNDayDate(gaoCaiHit.getGetDateEnd(), 1));
		}
		
		if (gaoCaiHit.getCatchDateEnd() != null) {
			gaoCaiHit.setCatchDateEnd(DateUtils.getNDayDate(gaoCaiHit.getCatchDateEnd(), 1));
		}
		
		
		List<GaoCaiHit> list = gaoCaiHitService.findAll(gaoCaiHit);
	
		
		PageInfo<GaoCaiHit> pageInfo = new PageInfo<GaoCaiHit>(list);
		
		
		model.addAttribute("pager", pageInfo);
		
		if (gaoCaiHit.getGetDateEnd() != null) {
			gaoCaiHit.setGetDateEnd(DateUtils.getNDayDate(gaoCaiHit.getGetDateEnd(), -1));
		}
		if (gaoCaiHit.getCatchDateEnd() != null) {
			gaoCaiHit.setCatchDateEnd(DateUtils.getNDayDate(gaoCaiHit.getCatchDateEnd(), -1));
		}
		
		return "modules/escapeFile/gaoCaiHitList";
	}
	
	
	//门户网站编辑页面
	@RequestMapping(value = "form")
	public String form( Model model,@ModelAttribute("gaoCaiHit")GaoCaiHit gaoCaiHit) {    
		
		
		
		return "modules/escapeFile/gaoCaiHitForm";
	}

	@RequestMapping(value = "preview")
	public String get( Model model,@ModelAttribute("gaoCaiHit")GaoCaiHit gaoCaiHit) {    
		
		return "modules/escapeFile/gaoCaiHitPreview";
	}
	
	//保存
	@RequestMapping(value = "save")
	public String saveIndex( Model model,GaoCaiHit gaoCaiHit) {  
		gaoCaiHitService.saveOrUpdate(gaoCaiHit);
		
		return "redirect:/doorwindow/gaoCaiHit/list";
		//return "modules/escapeFile/indexForm";
	}	
	
	
	@RequestMapping(value = "delete")
	public String delete( Model model,GaoCaiHit gaoCaiHit) {  
		gaoCaiHit.setDelFlag(1);
		gaoCaiHitService.saveOrUpdate(gaoCaiHit);
		return "redirect:/doorwindow/gaoCaiHit/list";
	}	
    //恢复
	@RequestMapping(value = "toBefore")
	public String toBefore( Model model,GaoCaiHit gaoCaiHit) {  
		gaoCaiHit.setDelFlag(0);
		gaoCaiHitService.saveOrUpdate(gaoCaiHit);
		return "redirect:/doorwindow/gaoCaiHit/list";
	}
	
	
	  @RequestMapping(value = "/excelUpload", method = {RequestMethod.POST },produces = "application/json;charset=UTF-8") 
		public  String excelUpload(Model model,@RequestParam MultipartFile fileCheck) throws UnsupportedEncodingException {  	
	    	
	    	
			int fileSize=(int)fileCheck.getSize()/1024/1024;
			if(fileSize>=Constants.MAX_FILESIZE){
				model.addAttribute("statusExcel", "附件太大，已超过10M");
				
			}
	    	
			    String oriName = fileCheck.getOriginalFilename();
				if(StringUtils.isNotBlank(oriName)){
					int index=oriName.lastIndexOf(".");
					String suffix = oriName.substring(index).toLowerCase();
					
					if(  !".xls".equals(suffix) ){
						model.addAttribute("statusExcel", "上传的excel格式为：.xls");
					}
				}else{
					model.addAttribute("statusExcel", "上传的excel格式为：.xls");
				}
			
			try {
				List<GaoCaiHit> tms=gaoCaiHitService.excel(fileCheck);
				//model.addAttribute("tms", tms);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			return "redirect:/doorwindow/honour/list";

			
		}	
	
	

	
	@RequestMapping(value = "/media", method = RequestMethod.POST)
	@ResponseBody
	public String image(
			HttpServletRequest request,
			HttpSession session,
			@RequestParam("filedata") MultipartFile file) throws Exception {
		
		return fileUpload(file,"/gaoCaiHit/media/",request,session);
		
	}
		
		
		private String fileUpload(MultipartFile mfile,String storePath,HttpServletRequest request,HttpSession session){

			// 取得原文件名
			String originName = mfile.getOriginalFilename();
			// 取得文件后缀
			String fileExt = originName.substring(originName.lastIndexOf(".") + 1);
			// 按时间戳生成图片文件名
			//String picture = System.currentTimeMillis() + "."+ fileExt;
		
			String fileName = UUID.randomUUID().toString()+ "."+fileExt;
			
			
			String	filePath=(Global.getConfig("document.sore.path")+File.separator+storePath).replace("/", File.separator);
			
			String error = "";
			try {
				File file = new File(filePath);
				if(!file.exists()){
					file.mkdirs();
				}
				mfile.transferTo(new File(filePath,fileName));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
				error = e.getMessage();
			}

			// 将图片路径按xheditor要求的json格式字符串返回
			
			String url = "http://" + request.getServerName() //服务器地址  
	                + ":"   
	                + request.getServerPort()       //端口号  
	                + request.getContextPath()      //项目名称  
	                + "/document/"+storePath+ "/" + fileName;	//upload/images/2012/11_09/20121109223012.jpg
			
			return "{\"err\":\"" + error + "\",\"msg\":\"" + url + "\"}";
		}
}

